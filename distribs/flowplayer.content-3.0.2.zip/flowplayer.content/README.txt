Version history:

3.0.2
-----
Changes:
- added public get and set functions for accessing the content view style property

3.0.1
-----
- dispatches the LOAD event when initialized (needed for flowplayer 3.0.2 compatibility)

3.0.0
-----
- 3.0.0-final release

beta3
-----
- does not change the text format initialized by the player

beta2
-----
- no changes, just practicing plugin versioning

beta1
-----
- First public beta release
